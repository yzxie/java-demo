insert into t_user(id, name, email, sex) values ('id1', 'xieyizun', 'xieyizun@163.com', 1);
insert into t_product(name, status, price, owner_id) values ('产品1', 1, 100.0, 'id1');
insert into t_product_quantity (product_id, num) values (1, 10);