package com.yzxie.study.eshopcommon.constant;

/**
 * Author: xieyizun
 * Version: 1.0
 * Date: 2019-08-25
 * Description:
 **/
public class OrderConst {

    public static final String ORDER_QUEUE = "order-queue";

}
