package com.yzxie.study.eshopqueue.queue;

import org.springframework.context.annotation.Configuration;

/**
 * Author: xieyizun
 * Version: 1.0
 * Date: 2019-08-25
 * Description:
 **/
@Configuration
public class RabbitMqConfig {

}
