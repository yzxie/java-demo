package com.yzxie.study.eshopcommon.constant;

/**
 * Author: xieyizun
 * Version: 1.0
 * Date: 2019-08-27
 * Description:
 **/
public class RedisConst {
    public static final String SECKILL_NUMBER_KEY_PREFIX = "seckill_number:";

    public static final String SECKILL_RESULT_KEY_PREFIX = "seckill_result:";
}
