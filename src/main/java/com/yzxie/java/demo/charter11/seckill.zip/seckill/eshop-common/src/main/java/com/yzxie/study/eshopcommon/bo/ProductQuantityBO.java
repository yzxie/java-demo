package com.yzxie.study.eshopcommon.bo;

/**
 * Author: xieyizun
 * Version: 1.0
 * Date: 2019-08-30
 * Description:
 **/
public class ProductQuantityBO {
}
