# 电子商务网站
## API网关：eshop-api
## 业务服务：eshop-biz
## 队列异步处理：eshop-queue
## 基础工具类：eshop-common